# Service Mesh Practice

Kind 클러스터 기반 Service Mesh 실습 환경.

## 사전 요구사항

- Docker Desktop
- Kind (`go install sigs.k8s.io/kind@latest`)
- kubectl
- Helm 3
- linkerd CLI (`curl -sL https://run.linkerd.io/install | sh`)
- istioctl (`curl -L https://istio.io/downloadIstio | sh -`)

## 빠른 시작

```bash
# 클러스터 생성
make cluster-up

# Linkerd 실습
make mesh-linkerd
make app-emojivoto

# Istio 실습
make mesh-istio
make app-bookinfo

# 정리
make clean
```

## 디렉토리 구조

| 디렉토리 | 설명 |
|----------|------|
| `cluster/` | Kind 3노드 클러스터 설정 |
| `apps/` | 샘플 애플리케이션 (emojivoto, bookinfo) |
| `linkerd/` | Linkerd 설치, 트래픽, 정책, 관측성 |
| `istio/` | Istio 설치(sidecar/ambient), 트래픽, 보안, 관측성 |
| `advanced/` | Gateway API, Flagger 카나리 |
